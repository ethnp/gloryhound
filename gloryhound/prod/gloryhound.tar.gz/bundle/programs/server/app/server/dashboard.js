(function(){Transactions.clean();
Items.clean();
Setup.setupData(this.userId);

})();
