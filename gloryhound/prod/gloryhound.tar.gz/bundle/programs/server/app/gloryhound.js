(function(){Router.map(function() {
  this.route('home', {path: '/'} );
  this.route('newGoal');
  this.route('userProfile');
  this.route('dashboard');
});

})();
