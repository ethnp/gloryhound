(function(){Router.route('/dashboard', function () {
  this.render('dashboard');
});


Router.route('/newItem', function () {
  this.render('newItem');
});


Router.route('/', function () {

});

})();
