(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var braintree;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/goltfisch:braintree-server/braintree.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
braintree = Npm.require('braintree');                                // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['goltfisch:braintree-server'] = {
  braintree: braintree
};

})();

//# sourceMappingURL=goltfisch_braintree-server.js.map
